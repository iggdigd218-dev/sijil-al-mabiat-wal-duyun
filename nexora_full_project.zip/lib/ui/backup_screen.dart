import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import '../core/format.dart';
import 'trial_ui.dart' show ensureFeatureUnlocked;
import '../core/theme.dart';
import '../data/cloud_sync.dart';
import '../data/google_drive_service.dart';
import '../data/providers.dart';
import 'widgets.dart';

/// النسخ الاحتياطي والاستعادة وسلة المهملات — نقل شاشة `backup.js`.
class BackupScreen extends ConsumerStatefulWidget {
  /// عند true تُعرض بدون Scaffold خاص بها (لتُضمَّن داخل تبويب).
  final bool embedded;
  const BackupScreen({super.key, this.embedded = false});

  @override
  ConsumerState<BackupScreen> createState() => _BackupScreenState();
}

class _BackupScreenState extends ConsumerState<BackupScreen> {
  bool _busy = false;
  bool _cloudLoading = true;
  String? _cloudError;
  GoogleAccountInfo? _googleAccount;
  GoogleDriveBackupInfo? _cloudBackup;

  /// تضمين صور العمليات داخل ملف النسخة (البند ١٣).
  bool _withImages = true;

  // ===== المزامنة السحابية عبر Firebase (رابط + رمز، بلا تسجيل دخول) =====
  final _cloudUrlCtrl = TextEditingController();
  final _cloudCodeCtrl = TextEditingController();
  Map<String, dynamic>? _cloudStatus;
  bool _cloudBusy = false;

  final GoogleDriveService _drive = GoogleDriveService.instance;

  @override
  void initState() {
    super.initState();
    _loadCloudState();
    _loadFirebaseState();
  }

  @override
  void dispose() {
    _cloudUrlCtrl.dispose();
    _cloudCodeCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadFirebaseState() async {
    final repo = ref.read(repoProvider);
    try {
      final cfg = await CloudSync.config(repo);
      if (!mounted) return;
      final status = await CloudSync.status(repo);
      if (!mounted) return;
      setState(() {
        _cloudUrlCtrl.text = cfg.backendUrl;
        _cloudCodeCtrl.text = cfg.code;
        _cloudStatus = status;
      });
    } catch (e) {
      if (mounted) setState(() => _cloudStatus = {'error': '$e'});
    }
  }

  Future<void> _saveCloudConfig() async {
    final repo = ref.read(repoProvider);
    try {
      await CloudSync.setBackendUrl(repo, _cloudUrlCtrl.text);
    } on ArgumentError catch (e) {
      if (mounted) showSnack(context, '${e.message}', error: true);
      return;
    }
    var code = _cloudCodeCtrl.text.trim();
    if (code.isEmpty) code = CloudSync.generateCode();
    final clean = await CloudSync.setCode(repo, code);
    _cloudCodeCtrl.text = clean;
    // إعادة تهيئة ناقل المزامنة السحابية فوراً حتى تسري الإعدادات الجديدة
    // على طابور العمليات دون انتظار إعادة تشغيل التطبيق.
    try {
      final engine = ref.read(syncEngineProvider);
      if (engine.hasStarted) await engine.reconfigureCloud();
    } catch (_) {}
    await _loadFirebaseState();
    if (mounted) showSnack(context, 'تم حفظ إعداد المزامنة السحابية ✅');
  }

  Future<void> _pushCloud() async {
    setState(() => _cloudBusy = true);
    try {
      final repo = ref.read(repoProvider);
      final payload = await repo.exportAll(withImages: _withImages);
      final r = await CloudSync.push(repo, payload);
      await _loadFirebaseState();
      if (!mounted) return;
      if (r['ok'] != true) {
        showSnack(
          context,
          '${r['error'] ?? 'تعذّر الرفع السحابي'}',
          error: true,
        );
      } else if (r['skipped'] == true) {
        showSnack(
          context,
          'النسخة السحابية أحدث من المحلية — لم يُرفع لتفادي الكتابة فوقها.',
        );
      } else {
        showSnack(context, 'تم رفع النسخة للسحابة ✅ (الرمز: ${r['code']})');
      }
    } catch (e) {
      if (mounted) showSnack(context, 'تعذّر الرفع السحابي: $e', error: true);
    } finally {
      if (mounted) setState(() => _cloudBusy = false);
    }
  }

  Future<void> _pullCloud() async {
    final repo = ref.read(repoProvider);
    final r = await CloudSync.pull(repo);
    if (r['ok'] != true) {
      if (mounted)
        showSnack(context, '${r['error'] ?? 'تعذّر السحب'}', error: true);
      return;
    }
    if (r['exists'] != true) {
      if (mounted) showSnack(context, 'لا توجد نسخة سحابية لهذا الرمز بعد.');
      return;
    }
    final confirm = await confirmDialog(
      context,
      title: '⚠️ استعادة من السحابة',
      message:
          'سيتم استبدال كل البيانات الحالية بآخر نسخة سحابية (${r['date'] ?? ''}). هل تريد المتابعة؟',
      danger: true,
    );
    if (!confirm) return;
    setState(() => _busy = true);
    try {
      final payload = r['payload'] as Map<String, Object?>;
      final count = await repo.importAll(payload);
      await _resyncGroupAfterRestore();
      bump(ref);
      if (mounted)
        showSnack(context, 'تمت الاستعادة من السحابة — $count سجل ✅');
    } catch (e) {
      if (mounted) showSnack(context, 'تعذّرت الاستعادة: $e', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _loadCloudState() async {
    GoogleAccountInfo? account;
    GoogleDriveBackupInfo? backup;
    String? cloudError;
    try {
      account = await _drive.restoreSession();
      if (account != null) {
        try {
          backup = await _drive.latestBackup();
        } catch (e) {
          cloudError = '$e';
        }
      }
    } catch (e) {
      cloudError = '$e';
    }
    if (!mounted) return;
    setState(() {
      _googleAccount = account;
      _cloudBackup = backup;
      _cloudError = cloudError;
      _cloudLoading = false;
    });
  }

  Future<File> _createBackupFile() async {
    final data =
        await ref.read(repoProvider).exportAll(withImages: _withImages);
    final json = const JsonEncoder.withIndent('  ').convert(data);
    final dir = await getTemporaryDirectory();
    final stamp =
        DateTime.now().toIso8601String().substring(0, 19).replaceAll(':', '-');
    final file = File('${dir.path}/nexora-backup-$stamp.nexora');
    await file.writeAsString(json, flush: true);
    return file;
  }

  Future<void> _backup() async {
    setState(() => _busy = true);
    try {
      final file = await _createBackupFile();
      await Share.shareXFiles([
        XFile(file.path),
      ], subject: 'نسخة احتياطية — إدارة البيانات');
      if (mounted) {
        final raw = await file.readAsString();
        final map = jsonDecode(raw) as Map;
        final n = (map['images'] as Map?)?.length ?? 0;
        showSnack(
          context,
          n > 0
              ? 'تم إنشاء النسخة ✅ (تتضمّن $n صورة)'
              : 'تم إنشاء النسخة الاحتياطية ✅',
        );
        await ref.read(repoProvider).notify(
              title: 'تم إنشاء نسخة احتياطية',
              body: n > 0 ? 'ملف النسخة يتضمّن $n صورة' : 'اكتمل تصدير بياناتك بنجاح',
              kind: 'success',
            );
      }
    } catch (e) {
      if (mounted) showSnack(context, 'تعذّر إنشاء النسخة: $e', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<int> _importJson(String raw) async {
    final cleaned = raw.startsWith('\uFEFF') ? raw.substring(1) : raw;
    final decoded = jsonDecode(cleaned);
    if (decoded is! Map) throw const FormatException('ملف غير صالح');
    final map = Map<String, Object?>.from(decoded);
    final count = await ref.read(repoProvider).importAll(map);
    await _resyncGroupAfterRestore();
    bump(ref);
    return count;
  }

  /// بعد استعادة المدير: تُجدول كل البيانات المستعادة كعمليات مزامنة
  /// فتصل رأساً إلى بقية أجهزة المجموعة (لا شيء يحدث خارج المجموعة).
  Future<void> _resyncGroupAfterRestore() async {
    try {
      final queued = await ref.read(repoProvider).resyncAllToGroup();
      if (queued > 0) {
        ref.read(syncEngineProvider).notifyNewOperation();
        if (mounted) {
          showSnack(context,
              'جارٍ مزامنة النسخة المستعادة إلى أجهزة المجموعة ($queued سجلًا) 🔄');
        }
      }
    } catch (_) {
      // المزامنة اللاحقة الدورية ستلتقط ما تبقى.
    }
  }

  Future<String> _readPickedFile(PlatformFile picked) async {
    // بعض مزوّدي Android يعيدون bytes أو readStream فقط بدل path محلي.
    final bytes = picked.bytes;
    if (bytes != null) return utf8.decode(bytes);
    final stream = picked.readStream;
    if (stream != null) {
      final all = <int>[];
      await for (final chunk in stream) {
        all.addAll(chunk);
      }
      return utf8.decode(all);
    }
    final path = picked.path;
    if (path == null) {
      throw const FormatException(
        'لم يعُد مزوّد الملفات محتوى قابلًا للقراءة.',
      );
    }
    return File(path).readAsString();
  }

  Future<void> _restore() async {
    final ok = await confirmDialog(
      context,
      title: '⚠️ استعادة نسخة احتياطية',
      message:
          'سيتم استبدال كل البيانات الحالية بمحتوى الملف. لا يمكن التراجع.\n\n'
          'يقبل التطبيق ملفات مدير الحسابات (‎.nexora‎) وملفات JSON من مدير الملفات '
          'ومزوّدي التخزين السحابي. الاستعادة ذرّية: إذا كان أي صف أو مرجع '
          'غير صالح فستظهر رسالة خطأ ولن تُطبّق استعادة جزئية.\n\nهل تريد المتابعة؟',
      confirmText: 'استعادة',
      danger: true,
    );
    if (!ok) return;

    setState(() => _busy = true);
    try {
      // withData مهم لأن بعض مزوّدي Android يعيدون content URI بلا path محلي.
      final res = await FilePicker.platform.pickFiles(
        type: FileType.any,
        withData: true,
      );
      if (res == null) return;
      final raw = await _readPickedFile(res.files.single);
      final n = await _importJson(raw);
      if (mounted) showSnack(context, 'تمت الاستعادة ✅ ($n سجلًا)');
    } catch (e) {
      if (mounted) showSnack(context, 'تعذّرت الاستعادة: $e', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<GoogleAccountInfo?> _ensureGoogleAccount() async {
    var account = _googleAccount ?? await _drive.restoreSession();
    account ??= await _drive.signIn();
    if (account != null) {
      GoogleDriveBackupInfo? backup;
      String? cloudError;
      try {
        backup = await _drive.latestBackup();
      } catch (e) {
        // نجاح الربط لا يعتمد على وجود نسخة سابقة، لكن نعرض فشل فحصها.
        cloudError = '$e';
      }
      if (mounted) {
        setState(() {
          _googleAccount = account;
          _cloudBackup = backup;
          _cloudError = cloudError;
        });
      }
    }
    return account;
  }

  Future<void> _connectGoogle() async {
    setState(() => _busy = true);
    try {
      final account = await _ensureGoogleAccount();
      if (mounted) {
        showSnack(
          context,
          account == null
              ? 'أُلغي ربط حساب Google.'
              : 'تم ربط ${account.email} ✅',
        );
      }
    } catch (e) {
      if (mounted) showSnack(context, 'تعذّر ربط Google: $e', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _uploadToGoogle() async {
    setState(() => _busy = true);
    try {
      final account = await _ensureGoogleAccount();
      if (account == null) return;
      final file = await _createBackupFile();
      final backup = await _drive.uploadLatest(file);
      if (mounted) {
        setState(() {
          _cloudBackup = backup;
          _cloudError = null;
        });
        showSnack(context, 'تم تحديث نسخة Google Drive ✅');
      }
    } catch (e) {
      if (mounted) showSnack(context, 'تعذّر رفع النسخة: $e', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _restoreFromGoogle() async {
    final ok = await confirmDialog(
      context,
      title: '⚠️ استعادة من Google Drive',
      message:
          'سيتم تنزيل آخر نسخة من الحساب المرتبط واستبدال بيانات هذا الجهاز. '
          'العملية ذرّية ولن تُطبّق إذا كان الملف غير صالح.\n\nهل تريد المتابعة؟',
      confirmText: 'تنزيل واستعادة',
      danger: true,
    );
    if (!ok) return;

    setState(() => _busy = true);
    try {
      final account = await _ensureGoogleAccount();
      if (account == null) return;
      final dir = await getTemporaryDirectory();
      final file = File(
        '${dir.path}/nexora-drive-${DateTime.now().millisecondsSinceEpoch}.nexora',
      );
      await _drive.downloadLatestTo(file);
      final n = await _importJson(await file.readAsString());
      if (mounted)
        showSnack(context, 'تم تنزيل النسخة واستعادتها ✅ ($n سجلًا)');
    } catch (e) {
      if (mounted)
        showSnack(context, 'تعذّرت الاستعادة من Google: $e', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _signOutGoogle() async {
    setState(() => _busy = true);
    try {
      await _drive.signOut();
      if (mounted) {
        setState(() {
          _googleAccount = null;
          _cloudBackup = null;
          _cloudError = null;
        });
        showSnack(context, 'تم تسجيل الخروج من Google.');
      }
    } catch (e) {
      if (mounted) showSnack(context, 'تعذّر تسجيل الخروج: $e', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _relinkGoogle() async {
    final ok = await confirmDialog(
      context,
      title: 'إعادة ربط حساب Google',
      message: 'سيُفصل الحساب الحالي وتختار حساب Google آخر.',
      confirmText: 'إعادة الربط',
      danger: true,
    );
    if (!ok) return;

    setState(() => _busy = true);
    try {
      await _drive.disconnect();
      if (mounted) {
        setState(() {
          _googleAccount = null;
          _cloudBackup = null;
          _cloudError = null;
        });
      }
      final account = await _drive.signIn();
      if (account != null && mounted) {
        final backup = await _drive.latestBackup();
        setState(() {
          _googleAccount = account;
          _cloudBackup = backup;
        });
        showSnack(context, 'تمت إعادة ربط ${account.email} ✅');
      }
    } catch (e) {
      if (mounted) showSnack(context, 'تعذّرت إعادة الربط: $e', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _shareToDriveDirectly() async {
    setState(() => _busy = true);
    try {
      final file = await _createBackupFile();
      await Share.shareXFiles([
        XFile(file.path),
      ], subject: 'نسخة احتياطية سحابية — Google Drive');
      if (mounted) {
        showSnack(
          context,
          'تم تجهيز النسخة لمشاركتها وحفظها في Google Drive ☁️',
        );
      }
    } catch (e) {
      if (mounted) showSnack(context, 'تعذّر تصدير النسخة: ', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final counts = ref.watch(countsProvider).valueOrNull ?? {};
    final trash = ref.watch(trashProvider);
    // جهاز العضو داخل مجموعة: نسخة احتياطية محلية فقط — لا تسجيل دخول
    // Google ولا مزامنة سحابية (تلك بيد المدير وحده حسب الصلاحية).
    final wsMode = ref.watch(workspaceModeProvider).valueOrNull ?? 'standalone';
    final wsOwner = ref.watch(isOwnerProvider).valueOrNull ?? true;
    final cloudAllowed = wsMode == 'standalone' || (wsMode != 'member' && wsOwner);
    // الاستعادة داخل المجموعة حكر على جهاز المدير — وتُزامن رأساً للأجهزة.
    final restoreAllowed = wsMode == 'standalone' || (wsMode != 'member' && wsOwner);

    return ListView(
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 96),
      children: [
        const SectionTitle('حالة البيانات'),
        StatCardGrid(
          children: [
            StatCard(
              title: 'الحسابات',
              value: '${counts['accounts'] ?? 0}',
              icon: Icons.people_alt_outlined,
              color: AppColors.primaryOf(context),
            ),
            StatCard(
              title: 'العمليات',
              value: '${counts['transactions'] ?? 0}',
              icon: Icons.receipt_long_outlined,
              color: AppColors.infoOf(context),
            ),
            StatCard(
              title: 'السندات',
              value: '${counts['vouchers'] ?? 0}',
              icon: Icons.receipt_outlined,
              color: AppColors.violetOf(context),
            ),
            StatCard(
              title: 'سلة المهملات',
              value: '${counts['trash'] ?? 0}',
              icon: Icons.delete_outline,
              color: AppColors.accentOf(context),
            ),
          ],
        ),
        const SizedBox(height: 20),
        const SectionTitle('النسخ الاحتياطي'),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'تُحفظ النسخة كملف واحد يحتوي كل الحسابات والعمليات والسندات '
                  'والأصناف والإعدادات، ويمكنك حفظه في هاتفك أو إرساله لنفسك.',
                  style: TextStyle(
                    fontSize: 12.5,
                    height: 1.6,
                    color: AppColors.text2Of(context),
                  ),
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  dense: true,
                  secondary: const Icon(Icons.image_outlined),
                  title: const Text(
                    'تضمين صور العمليات',
                    style: TextStyle(
                      fontSize: 13.5,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  subtitle: const Text(
                    'يجعل الملف أكبر لكنه ينقل الإيصالات والشعار معه إلى أي هاتف',
                    style: TextStyle(fontSize: 11.5),
                  ),
                  value: _withImages,
                  onChanged: (v) => setState(() => _withImages = v),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: _busy ? null : _backup,
                        icon: const Icon(Icons.backup_outlined),
                        label: const Text('إنشاء نسخة'),
                      ),
                    ),
                    if (restoreAllowed) ...[
                      const SizedBox(width: 10),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: _busy ? null : () async { if (await ensureFeatureUnlocked(context, ref, featureKey: 'restore', featureName: 'نقاط الاسترجاع', description: 'استرجع بياناتك من أي نسخة احتياطية أو ادمج قواعد البيانات بأمان.')) await _restore(); },
                          icon: const Icon(Icons.restore_outlined),
                          label: const Text('استعادة'),
                        ),
                      ),
                    ],
                  ],
                ),
                if (!restoreAllowed)
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text(
                      'الاستعادة داخل المجموعة متاحة لجهاز المدير فقط — '
                      'وعند استعادته نسخة تُزامن بياناتها تلقائياً إلى جهازك.',
                      style: TextStyle(
                        fontSize: 11.5,
                        height: 1.5,
                        color: AppColors.text3Of(context),
                      ),
                    ),
                  ),
                if (_busy) ...[
                  const SizedBox(height: 12),
                  const LinearProgressIndicator(),
                ],
              ],
            ),
          ),
        ),
        if (cloudAllowed) ...[
        const SizedBox(height: 20),
        const SectionTitle(
          'المزامنة السحابية (Firebase — رابط ورمز، بلا تسجيل دخول)',
        ),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'ضع رابط قاعدة Firebase ورمزًا سحابيًا موحَّدًا على كل أجهزتك، فتتزامن '
                  'البيانات بدون حساب أو تسجيل دخول. ارفع النسخة من هنا واسحبها على الجهاز الآخر.',
                  style: TextStyle(
                    fontSize: 12.5,
                    height: 1.6,
                    color: AppColors.text2Of(context),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _cloudUrlCtrl,
                  decoration: const InputDecoration(
                    labelText: 'رابط قاعدة البيانات السحابية',
                    hintText: 'https://xxxx-default-rtdb.firebaseio.com',
                    border: OutlineInputBorder(),
                    isDense: true,
                  ),
                  keyboardType: TextInputType.url,
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _cloudCodeCtrl,
                        textCapitalization: TextCapitalization.characters,
                        decoration: const InputDecoration(
                          labelText: 'الرمز السحابي (نفسه على أجهزتك)',
                          border: OutlineInputBorder(),
                          isDense: true,
                        ),
                      ),
                    ),
                    IconButton(
                      tooltip: 'رمز جديد',
                      onPressed: () =>
                          _cloudCodeCtrl.text = CloudSync.generateCode(),
                      icon: const Icon(Icons.refresh),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                if (_cloudStatus != null &&
                    _cloudStatus!['exists'] == true) ...[
                  Text(
                    'آخر نسخة سحابية: ${_cloudStatus!['updatedAt'] ?? ''}  ·  ${_cloudStatus!['sizeKb'] ?? ''}',
                    style: TextStyle(
                      fontSize: 12,
                      color: AppColors.text3Of(context),
                    ),
                  ),
                  const SizedBox(height: 8),
                ],
                if (_cloudStatus != null && _cloudStatus!['error'] != null)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Text(
                      'تعذّر الاتصال: ${_cloudStatus!['error']}',
                      style: const TextStyle(fontSize: 12, color: Colors.red),
                    ),
                  ),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: _cloudBusy ? null : _saveCloudConfig,
                        icon: const Icon(Icons.save_outlined),
                        label: const Text('حفظ'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: _cloudBusy ? null : () async { if (await ensureFeatureUnlocked(context, ref, featureKey: 'cloud_backup', featureName: 'النسخ الاحتياطي السحابي', description: 'نسخة يومية آمنة لبياناتك على السحابة تحميك من فقدان الهاتف.')) await _pushCloud(); },
                        icon: const Icon(Icons.cloud_upload_outlined),
                        label: const Text('رفع'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: FilledButton.tonalIcon(
                        onPressed: _cloudBusy ? null : () async { if (await ensureFeatureUnlocked(context, ref, featureKey: 'restore', featureName: 'الاستعادة من السحابة', description: 'استرجع آخر نسخة سحابية لبياناتك في أي وقت وعلى أي جهاز.')) await _pullCloud(); },
                        icon: const Icon(Icons.cloud_download_outlined),
                        label: const Text('سحب'),
                      ),
                    ),
                  ],
                ),
                if (_cloudBusy) ...[
                  const SizedBox(height: 10),
                  const LinearProgressIndicator(),
                ],
              ],
            ),
          ),
        ),
        const SizedBox(height: 20),
        const SectionTitle('النسخ السحابي عبر Google Drive'),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'تُحفظ نسخة واحدة خاصة بالتطبيق داخل appDataFolder، ولا يطلب '
                  'التطبيق صلاحية قراءة ملفات Drive العادية. لا يتم حفظ access token '
                  'داخل Nexora؛ تُحفظ هوية الحساب فقط ويُطلب OAuth عند الحاجة.',
                  style: TextStyle(
                    fontSize: 12.5,
                    height: 1.6,
                    color: AppColors.text2Of(context),
                  ),
                ),
                const SizedBox(height: 10),
                if (_cloudLoading)
                  const ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: SizedBox(
                      width: 24,
                      height: 24,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    ),
                    title: Text('جارٍ التحقق من حساب Google…'),
                  )
                else if (_googleAccount == null) ...[
                  const ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: Icon(Icons.account_circle_outlined),
                    title: Text('لا يوجد حساب Google مرتبط'),
                    subtitle: Text(
                      'اربط حسابًا لاستخدام الرفع والاستعادة على جهاز آخر.',
                    ),
                  ),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: _busy ? null : _connectGoogle,
                      icon: const Icon(Icons.login),
                      label: const Text('ربط حساب Google'),
                    ),
                  ),
                ] else ...[
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: CircleAvatar(
                      child: Text(
                        (_googleAccount!.email.isEmpty
                                ? 'G'
                                : _googleAccount!.email[0])
                            .toUpperCase(),
                      ),
                    ),
                    title: Text(
                      _googleAccount!.displayName?.trim().isNotEmpty == true
                          ? _googleAccount!.displayName!
                          : 'حساب Google مرتبط',
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                    subtitle: Text(_googleAccount!.email),
                    trailing: IconButton(
                      tooltip: 'تسجيل الخروج',
                      onPressed: _busy ? null : _signOutGoogle,
                      icon: const Icon(Icons.logout),
                    ),
                  ),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    dense: true,
                    leading: Icon(
                      Icons.cloud_done_outlined,
                      color: AppColors.primaryOf(context),
                    ),
                    title: Text(
                      _cloudBackup == null
                          ? 'لا توجد نسخة على Google Drive'
                          : 'آخر نسخة: ${Fmt.dateTime(_cloudBackup!.modifiedTime ?? DateTime.now())}',
                      style: const TextStyle(fontSize: 12.5),
                    ),
                    subtitle: _cloudBackup?.sizeLabel.isNotEmpty == true
                        ? Text(_cloudBackup!.sizeLabel)
                        : const Text('ستُنشأ النسخة عند أول رفع.'),
                  ),
                  Row(
                    children: [
                      Expanded(
                        child: FilledButton.icon(
                          onPressed: _busy ? null : () async { if (await ensureFeatureUnlocked(context, ref, featureKey: 'cloud_backup', featureName: 'النسخ السحابي عبر Google Drive', description: 'نسخة احتياطية خاصة داخل Google Drive تُحدَّث بضغطة واحدة.')) await _uploadToGoogle(); },
                          icon: const Icon(Icons.cloud_upload_outlined),
                          label: const Text('رفع / تحديث'),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: _busy ? null : () async { if (await ensureFeatureUnlocked(context, ref, featureKey: 'restore', featureName: 'الاستعادة من Google Drive', description: 'استرجع نسختك المحفوظة في Google Drive متى احتجتها.')) await _restoreFromGoogle(); },
                          icon: const Icon(Icons.cloud_download_outlined),
                          label: const Text('استعادة'),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Align(
                    alignment: AlignmentDirectional.centerStart,
                    child: TextButton.icon(
                      onPressed: _busy ? null : _relinkGoogle,
                      icon: const Icon(Icons.switch_account_outlined),
                      label: const Text('إعادة ربط حساب آخر'),
                    ),
                  ),
                ],
                if (_cloudError != null) ...[
                  const SizedBox(height: 6),
                  Text(
                    _cloudError!,
                    style: TextStyle(
                      color: AppColors.dangerOf(context),
                      fontSize: 11.5,
                    ),
                  ),
                ],
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    onPressed: _busy ? null : _shareToDriveDirectly,
                    icon: const Icon(Icons.drive_folder_upload_outlined),
                    label: const Text('رفع / حفظ في تطبيق Google Drive 📤'),
                  ),
                ),
                if (_busy) ...[
                  const SizedBox(height: 10),
                  const LinearProgressIndicator(),
                ],
              ],
            ),
          ),
        ),
        ], // نهاية أقسام السحابة (مخفية عن أجهزة الأعضاء)
        const SizedBox(height: 20),
        const SectionTitle('استخدام البيانات على أكثر من هاتف'),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.phonelink, color: AppColors.primaryOf(context)),
                    const SizedBox(width: 8),
                    const Expanded(
                      child: Text(
                        'نقل الحساب بين الأجهزة',
                        style: TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 14.5,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Text(
                  'التطبيق يعمل بلا إنترنت وكل البيانات محفوظة داخل جهازك، '
                  'ولا يوجد خادم يزامن الأجهزة لحظيًا. للعمل على هاتف ثانٍ:\n\n'
                  '١) أنشئ نسخة احتياطية هنا مع تضمين الصور.\n'
                  '٢) أرسل الملف إلى الهاتف الآخر (واتساب أو درايف أو كابل).\n'
                  '٣) في الهاتف الآخر: النسخ الاحتياطي ← استعادة، واختر الملف.\n\n'
                  'ملاحظة مهمة: الاستعادة تستبدل بيانات الجهاز الثاني بالكامل، '
                  'لذا استخدم جهازًا واحدًا للإدخال في الوقت نفسه وانقل النسخة '
                  'بعد انتهاء العمل، وإلا ضاعت إدخالات الجهاز الآخر. '
                  'المزامنة اللحظية بين جهازين تحتاج خادمًا واشتراكًا، وهي غير '
                  'مفعّلة في هذا الإصدار.',
                  style: TextStyle(
                    fontSize: 12.5,
                    height: 1.75,
                    color: AppColors.text2Of(context),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 20),
        SectionTitle(
          'سلة المهملات',
          actionLabel: 'تفريغ',
          onAction: () async {
            final ok = await confirmDialog(
              context,
              title: 'تفريغ سلة المهملات',
              message: 'سيُحذف كل ما بداخلها نهائيًا.',
              danger: true,
            );
            if (ok) {
              await ref.read(repoProvider).emptyTrash();
              bump(ref);
            }
          },
        ),
        trash.when(
          loading: () => const Padding(
            padding: EdgeInsets.all(20),
            child: Center(child: CircularProgressIndicator()),
          ),
          error: (e, _) => Text('$e'),
          data: (items) {
            if (items.isEmpty) {
              return const EmptyState(
                icon: Icons.delete_outline,
                title: 'السلة فارغة',
                message: 'كل ما تحذفه يُحفظ هنا مؤقتًا ويمكن استرجاعه.',
              );
            }
            return Column(
              children: items.map((t) {
                final created = DateTime.tryParse(
                  (t['created_at'] ?? '') as String? ?? '',
                );
                return Card(
                  margin: const EdgeInsets.only(bottom: 8),
                  child: ListTile(
                    leading: Icon(
                      Icons.restore_from_trash_outlined,
                      color: AppColors.accentOf(context),
                    ),
                    title: Text(
                      '${t['label'] ?? t['store']}',
                      style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 14,
                      ),
                    ),
                    subtitle: Text(
                      created == null ? '' : Fmt.dateTime(created),
                      style: const TextStyle(fontSize: 11.5),
                    ),
                    trailing: TextButton(
                      onPressed: () async {
                        await ref
                            .read(repoProvider)
                            .restoreFromTrash(t['id'] as int);
                        bump(ref);
                        if (context.mounted) {
                          showSnack(context, 'تم الاسترجاع ✅');
                        }
                      },
                      child: const Text('استرجاع'),
                    ),
                  ),
                );
              }).toList(),
            );
          },
        ),
      ],
    );
  }
}

/// سجل النشاط — نقل شاشة `activity.js`.
class ActivityScreen extends ConsumerWidget {
  const ActivityScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final acts = ref.watch(activityProvider);

    return acts.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => EmptyState(
        icon: Icons.error_outline,
        title: 'تعذّر تحميل السجل',
        message: '$e',
      ),
      data: (items) {
        if (items.isEmpty) {
          return const EmptyState(
            icon: Icons.history,
            title: 'لا نشاط بعد',
            message: 'كل إضافة أو تعديل أو حذف سيظهر هنا.',
          );
        }
        return ListView(
          padding: const EdgeInsets.fromLTRB(14, 12, 14, 96),
          children: [
            SectionTitle(
              'آخر التغييرات',
              actionLabel: 'مسح السجل',
              onAction: () async {
                final ok = await confirmDialog(
                  context,
                  title: 'مسح سجل النشاط',
                  message: 'سيُمسح السجل بالكامل.',
                  danger: true,
                );
                if (ok) {
                  await ref.read(repoProvider).clearActivity();
                  bump(ref);
                }
              },
            ),
            for (final a in items)
              Card(
                margin: const EdgeInsets.only(bottom: 8),
                child: InkWell(
                  borderRadius: BorderRadius.circular(12),
                  // نقرة على أي سطر تعرض نافذة تفاصيل كاملة للنشاط.
                  onTap: () => showActivityDetails(context, ref, a),
                  child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Row(
                    children: [
                      Container(
                        width: 8,
                        height: 8,
                        decoration: BoxDecoration(
                          color: AppColors.primaryOf(context),
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          '${a['text']}',
                          style: const TextStyle(
                            fontSize: 13.5,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            '${a['user_name'] ?? ''}',
                            style: TextStyle(
                              fontSize: 11,
                              color: AppColors.text3Of(context),
                            ),
                          ),
                          Text(
                            Fmt.relative(
                              DateTime.tryParse(
                                    (a['created_at'] ?? '') as String,
                                  ) ??
                                  DateTime.now(),
                            ),
                            style: TextStyle(
                              fontSize: 10.5,
                              color: AppColors.text3Of(context),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(width: 6),
                      Icon(Icons.chevron_left,
                          size: 18, color: AppColors.text3Of(context)),
                    ],
                  ),
                  ),
                ),
              ),
          ],
        );
      },
    );
  }
}

/// نافذة تفاصيل نشاط واحد: النص الكامل، النوع، المنفّذ، الوقت الدقيق،
/// وبيانات السجل المرتبط إن كان ما يزال موجوداً.
Future<void> showActivityDetails(
  BuildContext context,
  WidgetRef ref,
  Map<String, Object?> a,
) async {
  final refType = '${a['ref_type'] ?? ''}';
  final refId = '${a['ref_id'] ?? ''}';
  final created = DateTime.tryParse('${a['created_at'] ?? ''}');

  // اسم الجدول المرتبط بكل نوع مرجع في سجل النشاط.
  final table = switch (refType) {
    'account' => 'accounts',
    'tx' => 'transactions',
    'voucher' => 'vouchers',
    'item' => 'items',
    'item_category' => 'item_categories',
    'user' => 'users',
    'stock' => 'stock_moves',
    _ => null,
  };
  final typeLabel = switch (refType) {
    'account' => 'حساب',
    'tx' => 'عملية حسابية',
    'voucher' => 'سند',
    'item' => 'صنف',
    'item_category' => 'فئة أصناف',
    'user' => 'مستخدم',
    'stock' => 'حركة مخزون',
    'trash' => 'سلة المهملات',
    _ => refType.isEmpty ? '—' : refType,
  };

  // جلب السجل المرتبط (إن وُجد) لعرض أبرز حقوله.
  Map<String, Object?>? linked;
  if (table != null && refId.isNotEmpty) {
    try {
      final db = await ref.read(repoProvider).database;
      final rows = await db.query(table,
          where: 'id = ?', whereArgs: [refId], limit: 1);
      if (rows.isNotEmpty) linked = rows.first;
    } catch (_) {}
  }

  // أبرز الحقول المفهومة للعرض (بالعربية) حسب نوع السجل.
  final details = <(String, String)>[];
  void add(String label, Object? v) {
    final s = '$v'.trim();
    if (s.isNotEmpty && s != 'null') details.add((label, s));
  }

  if (linked != null) {
    add('الاسم', linked['name']);
    add('الرقم', linked['number']);
    add('البيان', linked['note'] ?? linked['description']);
    add('المبلغ', linked['amount']);
    add('العملة', linked['currency']);
    add('الكمية', linked['quantity']);
    add('الحالة', switch ('${linked['status']}') {
      'approved' => 'معتمد',
      'draft' => 'مسودة',
      'cancelled' => 'ملغى',
      _ => '',
    });
    final deleted = '${linked['deleted_at'] ?? ''}';
    if (deleted.isNotEmpty) details.add(('⚠️', 'هذا السجل محذوف حالياً'));
  }

  if (!context.mounted) return;
  await showDialog<void>(
    context: context,
    builder: (ctx) => AlertDialog(
      icon: Icon(Icons.history, color: AppColors.primaryOf(ctx)),
      title: const Text('تفاصيل النشاط', style: TextStyle(fontSize: 17)),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // النص الكامل للنشاط.
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppColors.surface2Of(ctx),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                '${a['text']}',
                style:
                    const TextStyle(fontWeight: FontWeight.w700, height: 1.6),
              ),
            ),
            const SizedBox(height: 12),
            _DetailRow(label: 'النوع', value: typeLabel),
            if (refId.isNotEmpty) _DetailRow(label: 'المعرّف', value: refId),
            _DetailRow(label: 'المنفّذ', value: '${a['user_name'] ?? '—'}'),
            if (created != null)
              _DetailRow(label: 'الوقت', value: Fmt.dateTime(created)),
            if (details.isNotEmpty) ...[
              const Divider(height: 20),
              Text('بيانات السجل المرتبط',
                  style: TextStyle(
                    fontSize: 12.5,
                    fontWeight: FontWeight.w700,
                    color: AppColors.text2Of(ctx),
                  )),
              const SizedBox(height: 6),
              for (final d in details) _DetailRow(label: d.$1, value: d.$2),
            ] else if (table != null) ...[
              const SizedBox(height: 8),
              Text(
                'السجل المرتبط لم يعد موجوداً (حُذف أو استُبدل).',
                style: TextStyle(
                    fontSize: 12, color: AppColors.text3Of(ctx)),
              ),
            ],
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx),
          child: const Text('إغلاق'),
        ),
      ],
    ),
  );
}

/// سطر تفاصيل (تسمية: قيمة) داخل نافذة تفاصيل النشاط.
class _DetailRow extends StatelessWidget {
  final String label;
  final String value;
  const _DetailRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: 70,
              child: Text(label,
                  style: TextStyle(
                      fontSize: 12.5, color: AppColors.text3Of(context))),
            ),
            Expanded(
              child: Text(value,
                  style: const TextStyle(
                      fontSize: 13, fontWeight: FontWeight.w600)),
            ),
          ],
        ),
      );
}
