import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import '../core/accounting.dart';
import '../core/format.dart';
import '../core/models.dart';
import '../core/theme.dart';
import '../data/providers.dart';
import 'tx_share.dart';
import 'widgets.dart';

/// عنصر في سلة نقطة البيع
class _CartEntry {
  final Item item;
  double quantity;
  double unitPrice;

  _CartEntry({
    required this.item,
    this.quantity = 1.0,
    required this.unitPrice,
  });

  double get total => quantity * unitPrice;
}

enum _PosPayment {
  cash('نقداً 💵', 'cash'),
  credit('آجل (على الحساب) 📑', 'credit'),
  partial('جزئي (مقدم + آجل) ⚖️', 'partial');

  final String label;
  final String code;
  const _PosPayment(this.label, this.code);
}

/// شاشة نقطة البيع ونظام المبيعات المتكامل
class PosScreen extends ConsumerStatefulWidget {
  const PosScreen({super.key});

  @override
  ConsumerState<PosScreen> createState() => _PosScreenState();
}

class _PosScreenState extends ConsumerState<PosScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabController;
  final Map<int, _CartEntry> _cart = {};
  int? _selectedCategoryId;
  String _searchQuery = '';
  final TextEditingController _searchCtrl = TextEditingController();

  // إعدادات الفاتورة
  int? _selectedCustomerId;
  _PosPayment _payment = _PosPayment.cash;
  final TextEditingController _paidCtrl = TextEditingController();
  final TextEditingController _discountCtrl = TextEditingController();
  final TextEditingController _notesCtrl = TextEditingController();
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchCtrl.dispose();
    _paidCtrl.dispose();
    _discountCtrl.dispose();
    _notesCtrl.dispose();
    super.dispose();
  }

  double get _subtotal =>
      _cart.values.fold<double>(0.0, (sum, e) => sum + e.total);

  double get _discount => double.tryParse(_discountCtrl.text.trim()) ?? 0.0;

  double get _netTotal => (_subtotal - _discount).clamp(0.0, double.infinity);

  int get _itemCount => _cart.values.fold<int>(0, (sum, e) => sum + e.quantity.toInt());

  void _addItem(Item item) {
    setState(() {
      if (_cart.containsKey(item.id)) {
        _cart[item.id]!.quantity += 1.0;
      } else {
        _cart[item.id!] = _CartEntry(
          item: item,
          quantity: 1.0,
          unitPrice: item.sellPrice > 0 ? item.sellPrice : item.buyPrice,
        );
      }
    });
  }

  void _removeItem(int itemId) {
    setState(() {
      _cart.remove(itemId);
    });
  }

  void _clearCart() {
    setState(() {
      _cart.clear();
      _selectedCustomerId = null;
      _payment = _PosPayment.cash;
      _paidCtrl.clear();
      _discountCtrl.clear();
      _notesCtrl.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(48),
        child: Container(
          color: Theme.of(context).colorScheme.surface,
          child: TabBar(
            controller: _tabController,
            tabs: const [
              Tab(icon: Icon(Icons.point_of_sale_outlined), text: 'نقطة البيع'),
              Tab(icon: Icon(Icons.history_edu_outlined), text: 'سجل المبيعات'),
            ],
          ),
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildPosSaleTab(),
          const _PosHistoryTab(),
        ],
      ),
      bottomNavigationBar: _tabController.index == 0 && _cart.isNotEmpty
          ? _buildCartBottomBar()
          : null,
    );
  }

  Widget _buildPosSaleTab() {
    final categories = ref.watch(itemCategoriesProvider).valueOrNull ?? [];
    final allItems = ref.watch(itemsProvider).valueOrNull ?? [];
    final currencies = ref.watch(currenciesProvider).valueOrNull ?? kDefaultCurrencies;
    final cur = currencies.first;

    final filteredItems = allItems.where((item) {
      if (_selectedCategoryId != null && item.categoryId != _selectedCategoryId) {
        return false;
      }
      if (_searchQuery.isNotEmpty) {
        final q = _searchQuery.toLowerCase();
        final matchName = item.name.toLowerCase().contains(q);
        final matchCode = (item.barcode ?? '').toLowerCase().contains(q);
        return matchName || matchCode;
      }
      return true;
    }).toList();

    return Column(
      children: [
        // شريط البحث
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 10, 14, 6),
          child: TextField(
            controller: _searchCtrl,
            decoration: InputDecoration(
              hintText: 'ابحث باسم الصنف أو الباركود...',
              prefixIcon: const Icon(Icons.search),
              isDense: true,
              suffixIcon: _searchQuery.isEmpty
                  ? null
                  : IconButton(
                      icon: const Icon(Icons.clear),
                      onPressed: () {
                        _searchCtrl.clear();
                        setState(() => _searchQuery = '');
                      },
                    ),
            ),
            onChanged: (v) => setState(() => _searchQuery = v.trim()),
          ),
        ),

        // فئات الأصناف
        SizedBox(
          height: 44,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 10),
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: FilterChip(
                  label: const Text('الكل'),
                  selected: _selectedCategoryId == null,
                  onSelected: (_) => setState(() => _selectedCategoryId = null),
                ),
              ),
              for (final cat in categories)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: FilterChip(
                    label: Text(cat.name),
                    selected: _selectedCategoryId == cat.id,
                    onSelected: (_) => setState(() => _selectedCategoryId = cat.id),
                  ),
                ),
            ],
          ),
        ),

        const SizedBox(height: 6),

        // شبكة الأصناف
        Expanded(
          child: filteredItems.isEmpty
              ? const EmptyState(
                  icon: Icons.inventory_2_outlined,
                  title: 'لا توجد أصناف مطابقة',
                  message: 'أضف أصنافاً من شاشة المخزون أو غيّر نص البحث.',
                )
              : GridView.builder(
                  padding: const EdgeInsets.fromLTRB(12, 6, 12, 90),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    childAspectRatio: 1.15,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                  ),
                  itemCount: filteredItems.length,
                  itemBuilder: (context, i) {
                    final item = filteredItems[i];
                    final inCart = _cart[item.id]?.quantity ?? 0.0;
                    final price = item.sellPrice > 0 ? item.sellPrice : item.buyPrice;
                    final isLow = item.minAlert != null && item.quantity <= item.minAlert!;
                    final isOut = item.quantity <= 0;

                    return Card(
                      elevation: inCart > 0 ? 2 : 0.5,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                        side: BorderSide(
                          color: inCart > 0
                              ? AppColors.primaryOf(context)
                              : Theme.of(context).dividerColor.withValues(alpha: 0.1),
                          width: inCart > 0 ? 2 : 1,
                        ),
                      ),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(12),
                        onTap: () => _addItem(item),
                        child: Padding(
                          padding: const EdgeInsets.all(10),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: Text(
                                      item.name,
                                      style: const TextStyle(
                                        fontWeight: FontWeight.w700,
                                        fontSize: 14,
                                      ),
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                  if (inCart > 0)
                                    CircleAvatar(
                                      radius: 12,
                                      backgroundColor: AppColors.primaryOf(context),
                                      child: Text(
                                        '${inCart.toInt()}',
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 11,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                ],
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    '${Fmt.money(price)} ${cur.symbol}',
                                    style: TextStyle(
                                      fontWeight: FontWeight.w800,
                                      fontSize: 13,
                                      color: AppColors.primaryOf(context),
                                    ),
                                  ),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 6, vertical: 2),
                                    decoration: BoxDecoration(
                                      color: (isOut
                                              ? AppColors.red
                                              : (isLow ? Colors.orange : AppColors.green))
                                          .withValues(alpha: 0.12),
                                      borderRadius: BorderRadius.circular(6),
                                    ),
                                    child: Text(
                                      '${Fmt.money(item.quantity)} ${item.unit}',
                                      style: TextStyle(
                                        fontSize: 11,
                                        fontWeight: FontWeight.w600,
                                        color: isOut
                                            ? AppColors.red
                                            : (isLow ? Colors.orange : AppColors.green),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }

  Widget _buildCartBottomBar() {
    final currencies = ref.watch(currenciesProvider).valueOrNull ?? kDefaultCurrencies;
    final cur = currencies.first;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.08),
            blurRadius: 10,
            offset: const Offset(0, -3),
          ),
        ],
      ),
      child: SafeArea(
        child: Row(
          children: [
            Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '$_itemCount صنف بالسلة',
                  style: TextStyle(
                    fontSize: 12,
                    color: AppColors.text2Of(context),
                  ),
                ),
                Text(
                  '${Fmt.money(_netTotal)} ${cur.symbol}',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    color: AppColors.primaryOf(context),
                  ),
                ),
              ],
            ),
            const Spacer(),
            IconButton.outlined(
              tooltip: 'إفراغ السلة',
              icon: const Icon(Icons.delete_sweep_outlined, color: AppColors.red),
              onPressed: _clearCart,
            ),
            const SizedBox(width: 8),
            FilledButton.icon(
              onPressed: _openCheckoutSheet,
              icon: const Icon(Icons.shopping_cart_checkout),
              label: const Text('إتمام الفاتورة'),
            ),
          ],
        ),
      ),
    );
  }

  void _openCheckoutSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Theme.of(context).colorScheme.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) {
        return StatefulBuilder(
          builder: (context, setSheetState) {
            final accounts = ref.watch(allAccountsProvider).valueOrNull ?? [];
            final currencies = ref.watch(currenciesProvider).valueOrNull ?? kDefaultCurrencies;
            final cur = currencies.first;
            final customers = accounts.where((a) => a.kind == AccountKind.customer || a.kind == AccountKind.general).toList();

            return DraggableScrollableSheet(
              initialChildSize: 0.85,
              minChildSize: 0.5,
              maxChildSize: 0.95,
              expand: false,
              builder: (_, scrollCtrl) {
                return ListView(
                  controller: scrollCtrl,
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'تفاصيل فاتورة المبيعات 🛒',
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                        IconButton(
                          icon: const Icon(Icons.close),
                          onPressed: () => Navigator.pop(context),
                        ),
                      ],
                    ),
                    const Divider(),

                    // قائمة أصناف السلة
                    const Text('الأصناف المختارة:', style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    for (final entry in _cart.values) ...[
                      Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(entry.item.name, style: const TextStyle(fontWeight: FontWeight.w600)),
                                Text(
                                  '${Fmt.money(entry.unitPrice)} ${cur.symbol} / ${entry.item.unit}',
                                  style: TextStyle(fontSize: 12, color: AppColors.text2Of(context)),
                                ),
                              ],
                            ),
                          ),
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                icon: const Icon(Icons.remove_circle_outline, size: 20),
                                onPressed: () {
                                  setSheetState(() {
                                    if (entry.quantity > 1) {
                                      entry.quantity -= 1;
                                    } else {
                                      _removeItem(entry.item.id!);
                                    }
                                  });
                                  setState(() {});
                                },
                              ),
                              Text('${entry.quantity.toInt()}', style: const TextStyle(fontWeight: FontWeight.bold)),
                              IconButton(
                                icon: const Icon(Icons.add_circle_outline, size: 20),
                                onPressed: () {
                                  setSheetState(() {
                                    entry.quantity += 1;
                                  });
                                  setState(() {});
                                },
                              ),
                            ],
                          ),
                          SizedBox(
                            width: 75,
                            child: Text(
                              '${Fmt.money(entry.total)} ${cur.symbol}',
                              textAlign: TextAlign.end,
                              style: const TextStyle(fontWeight: FontWeight.w700),
                            ),
                          ),
                        ],
                      ),
                      const Divider(height: 12),
                    ],

                    const SizedBox(height: 12),

                    // اختيار العميل
                    const Text('العميل:', style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 6),
                    DropdownButtonFormField<int?>(
                      value: _selectedCustomerId,
                      decoration: const InputDecoration(
                        isDense: true,
                        prefixIcon: Icon(Icons.person_outline),
                      ),
                      items: [
                        const DropdownMenuItem<int?>(
                          value: null,
                          child: Text('عميل نقدي (بدون حساب)'),
                        ),
                        for (final c in customers)
                          DropdownMenuItem<int?>(
                            value: c.id,
                            child: Text('${c.name} (${c.phone.isNotEmpty ? c.phone : 'بدون هاتف'})'),
                          ),
                      ],
                      onChanged: (val) {
                        setSheetState(() => _selectedCustomerId = val);
                        setState(() => _selectedCustomerId = val);
                      },
                    ),

                    const SizedBox(height: 16),

                    // نوع السداد
                    const Text('طريقة الدفع:', style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 6),
                    SegmentedButton<_PosPayment>(
                      segments: _PosPayment.values
                          .map((p) => ButtonSegment(value: p, label: Text(p.label)))
                          .toList(),
                      selected: {_payment},
                      onSelectionChanged: (set) {
                        setSheetState(() => _payment = set.first);
                        setState(() => _payment = set.first);
                      },
                    ),

                    if (_payment == _PosPayment.partial) ...[
                      const SizedBox(height: 12),
                      TextField(
                        controller: _paidCtrl,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(
                          labelText: 'المبلغ المدفوع مقدماً',
                          prefixIcon: Icon(Icons.payments_outlined),
                          isDense: true,
                        ),
                        onChanged: (_) {
                          setSheetState(() {});
                          setState(() {});
                        },
                      ),
                    ],

                    const SizedBox(height: 12),

                    // الخصم
                    TextField(
                      controller: _discountCtrl,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        labelText: 'مبلغ الخصم (اختياري)',
                        prefixIcon: Icon(Icons.discount_outlined),
                        isDense: true,
                      ),
                      onChanged: (_) {
                        setSheetState(() {});
                        setState(() {});
                      },
                    ),

                    const SizedBox(height: 16),

                    // الملخص المالي
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: AppColors.primarySoftOf(context),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('المجموع الفرعي:'),
                              Text('${Fmt.money(_subtotal)} ${cur.symbol}'),
                            ],
                          ),
                          if (_discount > 0) ...[
                            const SizedBox(height: 4),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                const Text('الخصم:', style: TextStyle(color: AppColors.red)),
                                Text('-${Fmt.money(_discount)} ${cur.symbol}',
                                    style: const TextStyle(color: AppColors.red)),
                              ],
                            ),
                          ],
                          const Divider(),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('الصافي الإجمالي:',
                                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                              Text(
                                '${Fmt.money(_netTotal)} ${cur.symbol}',
                                style: TextStyle(
                                  fontWeight: FontWeight.w900,
                                  fontSize: 18,
                                  color: AppColors.primaryOf(context),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 20),

                    // زر إتمام البيع
                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: FilledButton.icon(
                        onPressed: _saving ? null : () => _executeSale(context),
                        icon: _saving
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                              )
                            : const Icon(Icons.check_circle_outline),
                        label: Text(_saving ? 'جارٍ الحفظ…' : 'تأكيد وإصدار الفاتورة'),
                      ),
                    ),
                  ],
                );
              },
            );
          },
        );
      },
    );
  }

  Future<void> _executeSale(BuildContext sheetCtx) async {
    if (_cart.isEmpty) return;

    if ((_payment == _PosPayment.credit || _payment == _PosPayment.partial) &&
        _selectedCustomerId == null) {
      showSnack(context, 'البيع الآجل أو الجزئي يتطلب اختيار حساب العميل.', error: true);
      return;
    }

    setState(() => _saving = true);
    final repo = ref.read(repoProvider);

    try {
      final currencies = await repo.currencies();
      final cur = currencies.first;
      final refNum = 'POS-${DateTime.now().millisecondsSinceEpoch.toString().substring(7)}';

      // 1. تجهيز أسطر الفاتورة
      final lines = _cart.values.map((e) {
        return InvoiceLine(
          itemId: e.item.id,
          name: e.item.name,
          unit: e.item.unit,
          quantity: e.quantity,
          unitPrice: e.unitPrice,
          total: e.total,
        );
      }).toList();

      // 2. تحديد نوع وسجل العملية المالية
      late final int txId;
      final now = DateTime.now();

      if (_payment == _PosPayment.cash) {
        // مبيعات نقدية: إيراد
        final tx = Tx(
          accountId: _selectedCustomerId ?? 0,
          amount: _netTotal,
          currency: cur.code,
          type: OpType.income,
          date: now,
          description: 'فاتورة مبيعات نقدية رقم #$refNum',
          reference: refNum,
        );
        txId = await repo.saveTx(tx, items: lines);
      } else if (_payment == _PosPayment.credit) {
        // مبيعات آجلة: قيد مدين على العميل (عليه)
        final tx = Tx(
          accountId: _selectedCustomerId!,
          amount: _netTotal,
          currency: cur.code,
          type: OpType.debit,
          date: now,
          description: 'فاتورة مبيعات آجلة رقم #$refNum',
          reference: refNum,
        );
        txId = await repo.saveTx(tx, items: lines);
      } else {
        // مبيعات جزئية: قيد بالباقي + قبض بالمقدم
        final paid = double.tryParse(_paidCtrl.text.trim()) ?? 0.0;
        final remainder = (_netTotal - paid).clamp(0.0, double.infinity);

        // تسجيل المبلغ الكامل كمدين
        final debitTx = Tx(
          accountId: _selectedCustomerId!,
          amount: _netTotal,
          currency: cur.code,
          type: OpType.debit,
          date: now,
          description: 'فاتورة مبيعات جزئية رقم #$refNum (إجمالي الفاتورة)',
          reference: refNum,
        );
        txId = await repo.saveTx(debitTx, items: lines);

        // تسجيل الدفعة المسددة كقبض إن وجدت
        if (paid > 0) {
          final payTx = Tx(
            accountId: _selectedCustomerId!,
            amount: paid,
            currency: cur.code,
            type: OpType.receipt,
            date: now,
            description: 'دفعة مقدمة من فاتورة #$refNum',
            reference: '$refNum-PAY',
          );
          await repo.saveTx(payTx);
        }
      }

      // 3. خصم الكميات تلقائياً من المخزون
      for (final line in lines) {
        if (line.itemId != null) {
          try {
            await repo.addStockMove(StockMove(
              itemId: line.itemId!,
              quantity: line.quantity,
              kind: StockKind.out,
              date: now,
              notes: 'مبيع نقطة بيع #$refNum',
            ));
          } catch (e) {
            debugPrint('Failed to reduce stock for ${line.name}: $e');
          }
        }
      }

      // تحديث البيانات
      bump(ref);

      if (mounted) {
        Navigator.pop(sheetCtx); // إغلاق النموذج
        _showSuccessDialog(txId, refNum, lines);
        _clearCart();
      }
    } catch (e) {
      if (mounted) showSnack(context, 'تعذّر إتمام الفاتورة: $e', error: true);
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  void _showSuccessDialog(int txId, String refNum, List<InvoiceLine> lines) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) {
        return AlertDialog(
          title: const Row(
            children: [
              Icon(Icons.check_circle, color: AppColors.green),
              SizedBox(width: 8),
              Text('تمت العملية بنجاح ✅'),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('رقم الفاتورة: $refNum'),
              Text('عدد الأصناف: ${lines.length}'),
              const SizedBox(height: 12),
              const Text('يمكنك طباعة الإيصال الحراري أو مشاركة الفاتورة عبر واتساب مباشرة:'),
            ],
          ),
          actions: [
            OutlinedButton.icon(
              icon: const Icon(Icons.print_outlined),
              label: const Text('طباعة إيصال حراري (80mm)'),
              onPressed: () async {
                final repo = ref.read(repoProvider);
                final txs = await repo.transactions();
                final tx = txs.firstWhere((t) => t.id == txId);
                final accs = await repo.accounts(includeArchived: true);
                final acc = accs.where((a) => a.id == tx.accountId).firstOrNull;
                await _printThermalInvoice(tx, acc, lines);
              },
            ),
            FilledButton.icon(
              icon: const Icon(Icons.send_outlined),
              label: const Text('إرسال واتساب'),
              onPressed: () async {
                final repo = ref.read(repoProvider);
                final txs = await repo.transactions();
                final tx = txs.firstWhere((t) => t.id == txId);
                final accs = await repo.accounts(includeArchived: true);
                final acc = accs.where((a) => a.id == tx.accountId).firstOrNull;
                if (acc == null || acc.phone.isEmpty) {
                  showSnack(context, 'لا يوجد رقم هاتف مسجل للعميل', error: true);
                  return;
                }
                await TxShare.sendWhatsApp(
                  context: context,
                  ref: ref,
                  tx: tx,
                  account: acc,
                );
              },
            ),
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('فاتورة جديدة'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _printThermalInvoice(
    Tx tx,
    Account? account,
    List<InvoiceLine> lines,
  ) async {
    final repo = ref.read(repoProvider);
    final st = await repo.settings();
    final orgName = (st['businessName'] ?? 'المتجر').trim();
    final orgPhone = (st['phone'] ?? '').trim();
    final footer = (st['voucherFooter'] ?? 'شكراً لزيارتكم!').trim();

    final doc = pw.Document();
    doc.addPage(
      pw.Page(
        pageFormat: const PdfPageFormat(
          80 * PdfPageFormat.mm,
          double.infinity,
          marginAll: 4 * PdfPageFormat.mm,
        ),
        build: (pw.Context context) {
          return pw.Directionality(
            textDirection: pw.TextDirection.rtl,
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.center,
              children: [
                pw.Text(orgName, style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
                if (orgPhone.isNotEmpty)
                  pw.Text('هاتف: $orgPhone', style: const pw.TextStyle(fontSize: 10)),
                pw.Divider(thickness: 1),
                pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                  children: [
                    pw.Text('فاتورة مبيعات', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
                    pw.Text('#${tx.reference}'),
                  ],
                ),
                pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                  children: [
                    pw.Text('التاريخ: ${Fmt.date(tx.date)}'),
                    pw.Text('الوقت: ${tx.date.hour}:${tx.date.minute}'),
                  ],
                ),
                if (account != null)
                  pw.Align(
                    alignment: pw.Alignment.centerRight,
                    child: pw.Text('العميل: ${account.name}'),
                  ),
                pw.Divider(thickness: 1),
                for (final item in lines) ...[
                  pw.Row(
                    mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                    children: [
                      pw.Expanded(child: pw.Text(item.name, style: const pw.TextStyle(fontSize: 10))),
                      pw.Text(
                        '${item.quantity} × ${Fmt.money(item.unitPrice)} = ${Fmt.money(item.total)}',
                        style: const pw.TextStyle(fontSize: 10),
                      ),
                    ],
                  ),
                ],
                pw.Divider(thickness: 1),
                pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                  children: [
                    pw.Text('الإجمالي المطلوب:', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
                    pw.Text('${Fmt.money(tx.amount)} ${tx.currency}',
                        style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 13)),
                  ],
                ),
                pw.SizedBox(height: 8),
                pw.Text(footer, style: const pw.TextStyle(fontSize: 9), textAlign: pw.TextAlign.center),
              ],
            ),
          );
        },
      ),
    );

    await Printing.layoutPdf(
      onLayout: (_) => doc.save(),
      name: 'invoice-${tx.reference}.pdf',
    );
  }
}

/// تبويب سجل فواتير المبيعات
class _PosHistoryTab extends ConsumerWidget {
  const _PosHistoryTab();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final txData = ref.watch(txPageProvider);

    return txData.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => EmptyState(
        icon: Icons.error_outline,
        title: 'تعذّر تحميل سجل المبيعات',
        message: '$e',
      ),
      data: (page) {
        // تصفية فواتير المبيعات فقط (تحتوي على مرجع POS أو وصف فاتورة)
        final posTxs = page.items
            .where((t) =>
                t.reference.startsWith('POS') ||
                t.description.contains('فاتورة') ||
                t.type == OpType.income)
            .toList();

        if (posTxs.isEmpty) {
          return const EmptyState(
            icon: Icons.receipt_long_outlined,
            title: 'لا توجد فواتير مبيعات مسجلة',
            message: 'قم بإجراء عمليات بيع من تبويب نقطة البيع وستظهر هنا.',
          );
        }

        return ListView.separated(
          padding: const EdgeInsets.all(12),
          itemCount: posTxs.length,
          separatorBuilder: (_, __) => const SizedBox(height: 8),
          itemBuilder: (context, i) {
            final tx = posTxs[i];
            final account = page.accounts[tx.accountId];

            return Card(
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: AppColors.primarySoftOf(context),
                  child: const Icon(Icons.receipt, color: AppColors.teal),
                ),
                title: Text(
                  tx.reference.isNotEmpty ? 'فاتورة #${tx.reference}' : tx.description,
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                subtitle: Text(
                  '${account?.name ?? 'عميل نقدي'} • ${Fmt.date(tx.date)}',
                  style: TextStyle(fontSize: 12, color: AppColors.text2Of(context)),
                ),
                trailing: Text(
                  '${Fmt.money(tx.amount)} ${tx.currency}',
                  style: TextStyle(
                    fontWeight: FontWeight.w900,
                    fontSize: 14,
                    color: AppColors.primaryOf(context),
                  ),
                ),
                onTap: () async {
                  final repo = ref.read(repoProvider);
                  final items = await repo.transactionItems(tx.id!);
                  if (context.mounted) {
                    showDialog(
                      context: context,
                      builder: (_) => AlertDialog(
                        title: Text('تفاصيل ${tx.reference}'),
                        content: SizedBox(
                          width: double.maxFinite,
                          child: items.isEmpty
                              ? const Text('لا توجد أصناف مسجلة لهذه الفاتورة.')
                              : ListView.builder(
                                  shrinkWrap: true,
                                  itemCount: items.length,
                                  itemBuilder: (_, idx) {
                                    final it = items[idx];
                                    return ListTile(
                                      title: Text(it.name),
                                      trailing: Text('${it.quantity} × ${Fmt.money(it.unitPrice)} = ${Fmt.money(it.total)}'),
                                    );
                                  },
                                ),
                        ),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(context),
                            child: const Text('إغلاق'),
                          ),
                        ],
                      ),
                    );
                  }
                },
              ),
            );
          },
        );
      },
    );
  }
}
